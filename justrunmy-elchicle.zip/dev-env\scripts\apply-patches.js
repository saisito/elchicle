// Placeholder postinstall hook
// If we need to patch node_modules with patch-package, add patches under patches/ and they
// will be applied automatically. For now, this script is a no-op to avoid npm errors.
console.log("postinstall: no patches to apply");
